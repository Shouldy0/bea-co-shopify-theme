# Bea & Co. — Consegna

## Apri per primo
Anteprima dello store: http://127.0.0.1:8768/ (funziona finché il server locale di questa sessione è attivo).
Alternativa: cartella store-preview, da servire con un normale server HTTP locale. È un'anteprima, non un negozio pubblicato.

## Prodotto
- pdf/Beas-Calm-Alone-Guide.pdf — 16 pagine, revisione editoriale.
- pdf/Beas-Calm-Alone-Workbook.pdf — 5 pagine, 25 campi compilabili.
- pdf/Beas-Quick-Reference.pdf — 1 pagina.
- brand/guide-preview.pdf — campione pubblico limitato a 3 pagine.

## Shopify
Nuovo prodotto salvato in bozza con descrizione e SEO aggiornati, prezzo 29 USD:
https://admin.shopify.com/store/u21aen-nm/products/15973890589003

Tema importabile: shopify/Bea-Calm-Shopify.zip.
Stato, limite del caricamento e istruzioni: shopify/INSTALLAZIONE.md.
I PDF non risultano caricati e il tema nuovo non risulta importato: il browser non ha permesso di selezionare i file locali corretti. La selezione non pertinente è stata annullata. Nessun ordine di prova o pagamento effettuato.

Sulla scheda originale già online sono stati corretti descrizione, numero di pagine, capitoli e natura stampabile dei tracker. Il PDF originale e il tema attivo sono conservati.

## Lancio
- launch/launch-copy.md — post, pin e bozza email di consegna.
- launch/validation-plan.md — test con lettori e misurazione.
- launch/revision-notes.md — modifiche editoriali e limiti della revisione.
- brand/brand-notes.md — identità visiva e posizionamento.

## Verifica eseguita
- PDF: tutte le pagine renderizzate e controllate.
- Workbook: 25 campi verificati dopo scrittura/riapertura, inclusi valori e appearance streams.
- Tema: sintassi Liquid verificata su 15 file con LiquidJS; schema JSON e template verificati localmente. Questa verifica non equivale alla compilazione nel runtime Shopify.
- Anteprima: homepage, pagina prodotto e carrello vuoto renderizzati; immagini caricate; adattamento mobile e collegamento al prodotto controllati.

## Da verificare dopo il caricamento
Rendering Shopify, associazione dei tre PDF, invio automatico, email e download dopo ordine test. Verifica professionale veterinaria non svolta. Nessuna validazione commerciale o legale dichiarata.
