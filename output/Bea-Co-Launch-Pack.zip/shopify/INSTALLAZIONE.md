# Bea & Co. — Stato e installazione

## Già fatto
- Nuova edizione: guida di 16 pagine, workbook di 5 pagine con 25 campi compilabili, scheda rapida di 1 pagina.
- Tutti i PDF controllati visivamente; campi verificati con salvataggio e riapertura.
- Nuova scheda Shopify salvata in bozza: Bea's Calm-Alone Kit, 29 USD, prodotto non fisico, inventario non tracciato.
- URL amministrativo: https://admin.shopify.com/store/u21aen-nm/products/15973890589003
- Handle del nuovo kit: beas-calm-alone-kit.
- Tema nativo Shopify confezionato: Bea-Calm-Shopify.zip.
- Anteprima locale della homepage, pagina prodotto e carrello vuoto.

## Blocco concreto
Il selettore file del browser non ha restituito un filechooser controllabile. È comparsa una selezione di immagini non pertinenti: annullata, senza salvare l'associazione al prodotto. Nessuno dei PDF nuovi risulta caricato. Nessun nuovo tema risulta importato. Il tema Horizon attivo non è stato sostituito. La descrizione della vecchia scheda è stata corretta: 24 pagine, 6 capitoli, tracker stampabili non interattivi e limiti educativi espliciti. Il PDF originale associato è conservato.

## Per completare su Shopify
1. Aprire la nuova scheda in bozza e, in Digital Products > Add assets > File, scegliere i tre file nella cartella output/pdf. Verificare nomi e numero: 3.
2. In Manage assets verificare invio automatico e limiti desiderati; salvare. Non caricare i PDF integrali nei file pubblici del tema.
3. In Media aggiungere le anteprime guida e workbook dalla cartella del tema, oltre alla foto di Bea se desiderato.
4. Online Store > Themes > Import > Upload zip file: scegliere Bea-Calm-Shopify.zip. Shopify lo importa come bozza.
5. Aprire l'editor del tema Bea Calm e scegliere Bea's Calm-Alone Kit nel campo Featured kit della sezione Bea home. Il codice ha già come fallback l'handle beas-calm-alone-kit.
6. Controllare il rendering Shopify e il prodotto in anteprima. I prezzi e le form native dipendono dal runtime Shopify; la simulazione locale non sostituisce questo controllo.
7. Verificare le policy reali e le impostazioni pertinenti ai mercati serviti. Non è stata dichiarata conformità fiscale o legale. Non sono state inventate condizioni di rimborso, indirizzi o dati aziendali.
8. Provare un acquisto in modalità test autorizzata, verificando consegna email e accesso ai tre PDF. Non sono stati effettuati pagamenti o ordini reali.
9. Quando pronto, attivare il nuovo prodotto e pubblicare il tema. La vecchia edizione può essere messa in bozza conservandone file e storico. Valutare un redirect dall'URL digital-product alla nuova scheda, mantenendo lo storico ordini.

## Limiti da conoscere
- Revisione editoriale, non validazione veterinaria. Il testo finale è un supporto educativo e organizzativo, senza promessa di cura o tempi.
- Il tema usa sezioni native, form prodotto/carrello/contatto native Shopify e blocchi app nella pagina prodotto. L'editor permette di scegliere il prodotto; i testi editoriali si modificano nei file Liquid.
- L'anteprima locale usa dati dimostrativi del kit. Non processa pagamenti né invia messaggi.
- Il PDF pubblico guide-preview.pdf contiene solo copertina, indice ed esempio fittizio. Nessun file integrale del kit è negli asset del tema.
- Il kit resta in inglese, come l'originale. Il prezzo esistente di 29 USD è mantenuto; non è un prezzo validato tramite vendite.
